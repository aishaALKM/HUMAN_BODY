package com.example.humanbody;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivityForM extends AppCompatActivity {
    // this is the MainActivity of Respiratory system but I called it ActivityForM

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_for_m);
    }
}