package com.example.humanbody;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
// Recycler review code:Bundle,ImageView,TextView,

public class MainActivity10Maimpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity10_maimpage);

        Bundle b = getIntent().getExtras();
        human_body p = (human_body) b.getSerializable("QU");

        ImageView img = findViewById(R.id.picture);
        TextView QU = findViewById(R.id.textView4);
        TextView anser = findViewById(R.id.textView5);


        img.setImageResource(p.getImage());
        QU.setText(p.getQU());
        anser.setText(p.getAnswer());

    }
}