package com.example.humanbody;
// intents
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity2 extends AppCompatActivity {

    Button play;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //Sound Mp3

        play = (Button)findViewById(R.id.button_play);
        final MediaPlayer mp = MediaPlayer.create(MainActivity2.this,R.raw.moment);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mp.isPlaying()){
                    mp.pause();
                    play.setBackgroundResource(R.drawable.speakermute);

                }else{
                    mp.start();
                    play.setBackgroundResource(R.drawable.opengg);
                }
            }
        });



        // INTENT TO MainActivity9 = QU
        ImageButton a = findViewById(R.id.imageButton4);
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent o = new Intent(MainActivity2.this, MainActivity9.class);
                startActivity(o);
            }
        });
        // INTENT TO MainActivity8 = test
        ImageButton b = findViewById(R.id.imageButton5);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent klo = new Intent(MainActivity2.this, MainActivity8.class);
                startActivity(klo);


                    }
        });
        // the bookshop image = image3

        ImageButton c = findViewById(R.id.imageButton3);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = "https://www.instagram.com/jarirkuwait/?igshid=1dknois01zl36"; //
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);


            }
        });
        // the youtube image = image6

        ImageButton d = findViewById(R.id.imageButton6);
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent mj = new Intent(MainActivity2.this,MainActivity6 .class);
               startActivity(mj);
            }
        });

        // buttons for images = {1:heart,2:lungs,3:bones,4:nerves}

        Button so = findViewById(R.id.button3);
        so.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mjp = new Intent(MainActivity2.this,MainActivity4 .class);
                startActivity(mjp);
            }
        });

        Button som = findViewById(R.id.button5);
        som.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mjpu = new Intent(MainActivity2.this,ActivityForM .class);
                startActivity(mjpu);
            }
        });


        Button oi = findViewById(R.id.button);
        oi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moi = new Intent(MainActivity2.this,MainActivity3 .class);
                startActivity(moi);
            }
        });

        Button lg = findViewById(R.id.button2);
        lg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent kf = new Intent(MainActivity2.this,MainActivity5 .class);
                startActivity(kf);
            }
        });







    }
}