package com.example.humanbody;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.Queue;

// Recycler review code

public class MainActivity9 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main9);

        ArrayList<human_body>  human = new ArrayList<>();

        human_body h1 = new human_body("هل ينام القلب ؟",R.drawable.heartooop,"لا,فالقلب عضلة تعمل كمضخة في الليل و النهار ");
        human_body h2 = new human_body("كم عدد العظام الموجودة في جسم الإنسان ؟",R.drawable.skeletonyou,"يبلغ عدد العظام في جسم الإنسان 206 عظمة , ولها أحجام و أشكال");
        human_body h3 = new human_body("ما هو الحبل الشوكي ؟",R.drawable.brainplob,"هو بنية طويلة رقيقة أنبوبية الشكل , تبدأ عند نهاية جذع الدماغ");
        human_body h4 = new human_body("هل الخلية تتنفس ؟",R.drawable.cellcell,"نعم,فالخلية تتنفس الأوكسجين الذي نحصل عليه من الهواء , و تتغذى من السكر الذي نحصل عليه من الطعام");
        human_body h5 = new human_body("ما هو القفص الصدري ؟",R.drawable.ribsss,"يتكون القفص الصدري من مجموعة عظام متصلة , تعمل على حماية كافة الأعضاء المتواجدة في داخله");
        human_body h6 = new human_body("هل كل الحيوانات لديها عظام ؟",R.drawable.turtle,"لا , فالأخطبوط لا يملك أي عظمة مما يجعله من الرخويات");
        human_body h7 = new human_body("ما هي الرخويات ؟",R.drawable.jellyfish,"الرخويات هي الحوانات التي لا تملك عظام , تتكون الرخويات من أجسام طرية و تتألف عادةً من رأس و قدم");
        human_body h8 = new human_body("ما هي وظيفة كرات الدم الحمراء ؟",R.drawable.redblood,"تعتبر خلايا الدم الحمراء من أهم الخلايا في جسم الإنسان , فهي تقوم بالعديد من الوظائف مثل: نقل الأوكسجين إلى جميع خلايا الجسم , عملية البناء و الهدم ");
        human_body h9 = new human_body("ما هي كرات الدم البيضاء ؟",R.drawable.whitebloodcell,"هي إحدى خلايا الدم في الجسم , و وظيفتها الرئيسة هي الدفاع عن الجسم و محاربة الفايروسات و الأمراض");
        human_body h10 = new human_body("ما هي أطول عظمة في جسم الإنسان ؟",R.drawable.skeletonu,"عظام الساق , يمتد من مفصل الورك إلى الركب");
        human_body h11 = new human_body("لماذا العظام صلبة ؟",R.drawable.skull,"تتكون العظام من إطار بروتيني يسمى الكولاجين مع معدن يسمى ب فوسفات الكالسيوم مما يجعل الإطار صلب و قوي");
        human_body h12 = new human_body("ما هي الأعصاب ؟",R.drawable.nervesss,"العصب عبارة عن حزمة من شعيرات عصبية دقيقة مرتبطة عبر المحاور العصبية");
        human_body h14 = new human_body("ما هي الخلية ؟",R.drawable.bacterium,"الخلية هي الوحدة الأساسية في الكائنلت الحية , فكل الكائنات الحية تتكون من خلية و أكثر");
        human_body h16 = new human_body("كم عدد الخلايا في جسم الإنسان ؟",R.drawable.cellow,"100 تريلون خلية , لا يمكن رؤية الخلية بالعين المجردة إلا ان اختراع المجهر و خاصةً الإلكتروني ساعد بشكل كبير التعرف على شكل الخلايا");
        human_body h17 = new human_body("ما هي الأوعية الدموية ؟",R.drawable.bloodblood,"هي شبكات من الأنابيب المفرغة التي تنقل الدم في جميع أنحاء الجسم");
        human_body h18 = new human_body("لماذا الدم لونه أحمر ؟",R.drawable.blood,"يعود ذلك إلى مادة الهيموغلونين الموجودة في الدم");
        human_body h19 = new human_body("كيف أجعل جسمي مقاوماً الأمراض ؟",R.drawable.strongggs,"بممارسة التمارين البسيطة و و الحصول على القدر الكافي من النوم , تقوية الجهاز المناعي بتناول طعام صحي متوازن");
        human_body h20 = new human_body("لماذا ننام مبكراً ؟ً",R.drawable.yuios,"للحفاظ على صحة العينين و الوقاية من الأمراض , النوم المبكر لديه الكثير من الفوائد مثل: التخلص من السموم و حماية الجهاز الهضمي");
        human_body h21 = new human_body("من أين تأتي كريات الدم ؟",R.drawable.bloodcells,"تأتي كريات الدم الحمراء و البيضاء عن طريق نخاع العظام , حيث تتطور الخلايا الجذعية لنخاع العظام إل" +
                "ى خلايا الدم الحمراء والبيضاء و صفائح الدم");


        human.add(h1);
        human.add(h2);
        human.add(h3);
        human.add(h4);
        human.add(h5);
        human.add(h6);
        human.add(h7);
        human.add(h8);
        human.add(h9);
        human.add(h10);
        human.add(h11);
        human.add(h12);
        human.add(h14);
        human.add(h16);
        human.add(h17);
        human.add(h18);
        human.add(h19);
        human.add(h20);
        human.add(h21);

        RecyclerView rv = findViewById(R.id.rvh);
        rv.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));

        rv.setHasFixedSize(true);
        RecyclerView.LayoutManager kp = new LinearLayoutManager(this);
        rv.setLayoutManager(kp);

        humanhAdapter po = new humanhAdapter(human,this);
        rv.setAdapter(po);

    }
}