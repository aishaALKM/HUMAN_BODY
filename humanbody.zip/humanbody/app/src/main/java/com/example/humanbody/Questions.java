package com.example.humanbody;

// java class for the test = MainActivity8

public class Questions {
    public String mQuestions[] = {
            "ما هي أطول عظمة في جسم الإنسان ؟",
            "كم عدد العظام في جسم الإنسان ؟",
            "حيوان يعتبر من الرخويات ؟",
            "هل ينام القلب ؟",
            "لون كريات الدم الحمراء ؟",
            "هل الخلية تتنفس ؟",
            "كم عدد عظام القفص الصدري ؟",
            "ما هو لون الدم ؟",
            "ما هي فائدة كريات الدم الحمراء ؟"



    };

    private String mChoices[][] = {
            {"عظام الترقوة", "عظم الشظية", "الجمجمة", "عظام الساق"},
            {"756894", "100", "88", "206"},
            {"الأرنب", "الفأر", "السمك", "الأخطبوط"},
            {"ينام عندما أنام", "أحياناً", "لا", "نعم"},
            {"أصفر", "أبيض", "أخضر", "أحمر"},
            {"ربما", "أحيانااً", "لا", "نعم"},
            {"3854564", "58", "3", "12"},
            {"أخضر", "أسود", "أبيض", "أحمر"},
            {"نقل الرسائل من الدماغ", "صنع الملابس", "الدفاع عن الجسم ضد الأمراض و الفايروسات", "نقل الأوكسجين و الغذاء إلى جميع خلايا الجسم"},

    };
    // private String mCorrectAnswers[] = { "نقل الأوكسجين و الغذاء إلى جميع خلايا الجسما", "أحمر", "12", "نعم", "أحمر", "لا", "الأخطبوط", "260", "عظام الساق"};
    private String mCorrectAnswers[] = {"عظام الساق", "260", "الأخطبوط", "لا", "أحمر", "نعم", "12","أحمر", "نقل الأوكسجين و الغذاء إلى جميع خلايا الجسم"};
    public String getQuestion(int a){
        String question = mQuestions[a];
        return question;
    }

    public String getChoice1(int a){
        String choice = mChoices[a][0];
        return choice;
    }

    public String getChoice2(int a){
        String choice = mChoices[a][1];
        return choice;
    }
    public String getChoice3(int a){
        String choice = mChoices[a][2];
        return choice;
    }
    public String getChoice4(int a){
        String choice = mChoices[a][3];
        return choice;
    }

    public String getCorrectAnswers(int a){
        String answer = mCorrectAnswers[a];
        return answer;
    }




}
