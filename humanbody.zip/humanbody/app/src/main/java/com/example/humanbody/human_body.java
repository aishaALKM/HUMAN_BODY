package com.example.humanbody;

import java.io.Serializable;

// class for the Recycler review

public class human_body implements Serializable {

        private int image;
        private String QU;
        private String answer;

        public int getImage() {
            return image;
        }

        public void setImage(int image) {
            this.image = image;
        }

        public String getQU() {
            return QU;
        }

        public void setQU(String QU) {
            this.QU = QU;
        }

        public String getAnswer() {
            return answer;
        }

        public void setAnswer(String answer) {
            this.answer = answer;
        }


        public human_body(String QU,int image,String answer){
            this.image = image;
            this.QU = QU;
            this.answer = answer;
        }
    }




