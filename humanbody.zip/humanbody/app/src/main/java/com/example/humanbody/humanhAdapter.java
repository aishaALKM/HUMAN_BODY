package com.example.humanbody;

// the Adapter of the Recycler review

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

 import java.util.ArrayList;
 public class humanhAdapter extends RecyclerView.Adapter {
     ArrayList<human_body> pArray ;
     Context context;

     public humanhAdapter(ArrayList<human_body> pArray, Context context) {
         this.pArray = pArray;
         this.context = context;
     }

     @NonNull
     @Override
     public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
         View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.human_list_item,parent,false);
         ViewHolder vh = new ViewHolder(v);
         return vh;
     }

     //(ViewHolders)

     @Override
     public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
         ((ViewHolder)holder).image.setImageResource(pArray.get(position).getImage());
         ((ViewHolder)holder).textView.setText(pArray.get(position).getQU());
         ((ViewHolder)holder).view.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Intent kl = new Intent (context,MainActivity10Maimpage.class);
                 kl.putExtra("QU",pArray.get(position));
                 context.startActivity(kl);

             }
         });
     }


     @Override
     public int getItemCount() {
         return pArray.size();
     }
     public static class ViewHolder extends RecyclerView.ViewHolder{

         public  ImageView image ;
         public TextView textView;
         public View view ;

         public ViewHolder(@NonNull View itemView) {
             super(itemView);
             view = itemView;
             image = itemView.findViewById(R.id.blue);
             textView = itemView.findViewById(R.id.textView3);
         }
     }

}














